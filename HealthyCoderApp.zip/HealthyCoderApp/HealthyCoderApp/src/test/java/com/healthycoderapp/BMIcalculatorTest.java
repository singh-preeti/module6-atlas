package com.healthycoderapp;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertThrows;
import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

public class BMIcalculatorTest {

	@Test
	void should_ReturnFalse_When_DietRecommended() {
		//assertTrue(BMICalculator.isDietRecommended(89.0,1.72));
		
		//given
		 double weight = 95.0;
		 double height = 1.72;
		//when
		  boolean recommended = BMICalculator.isDietRecommended(weight,height);
		//then
		  assertFalse(recommended);
	}
	@Test
	void should_ReturnThrowsArithmeticException_When_HeightZero() {
		//assertTrue(BMICalculator.isDietRecommended(89.0,1.72));
		
		//given
		 double weight = 50.0;
		 double height = 0.00;
		//when
		  Executable executable = () -> BMICalculator.isDietRecommended(weight,height);
		//then
		  assertThrows(ArithmeticException.class,executable);
	}

}
